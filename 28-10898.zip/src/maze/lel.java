package maze;

public class lel {
public void someOneIsSaying()
{
	System.out.println("\u0623\ufee7\ufe8e \ufefb \u0623\ufead\u0649 \u0623\u0646 \ufeeb\ufee8\ufe8e\u0643 \ufee3\ufee6 \ufef3\ufed8\ufeee\u0644 ");
	someOneIsSaying();
}
public static void main(String[] args) {
	lel x = new lel();
	x.someOneIsSaying();
}
}
