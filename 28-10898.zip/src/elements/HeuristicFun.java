package elements;

public interface HeuristicFun {
	
	public int getHeuristicCost(State state);
	
}
