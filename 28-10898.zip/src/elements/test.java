package elements;

public class test {
public static void main(String[] args) {
	double [][] data = {{1,5.1,1.4,1},{2,4.9,1.4,1},{3,4.7,1.3,1},{4,4.6,1.5,1},{5,5.0,1.4,1}, {51,7.0,4.7,-1},{52,6.4,4.5,-1},{53,6.9,4.9,-1},{54,5.5,4.0,-1}, {55,6.5,4.6,-1}};
	for (int i = 0; i < data.length; i++) {
		
	}
}
}



