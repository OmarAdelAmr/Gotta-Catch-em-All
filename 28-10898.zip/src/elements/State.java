package elements;

public abstract class State
{
	public abstract boolean equals(Object y);
}
